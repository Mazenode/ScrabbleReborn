N'ayant pas r�ussi � passer l'�tape de la compilation du .jar, le seul moyen de compiler est d'ouvir le jeu est de
le lan�er depuis un IDE (Eclipse ou IntelliJIdea). Le fichier Main se trouve dans Main.Main, c'est celui que vous
devez lancer pour d�marrer le programme.